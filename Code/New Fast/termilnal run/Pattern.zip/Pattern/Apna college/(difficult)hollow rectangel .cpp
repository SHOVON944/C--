#include <iostream>
using namespace std;

int main()
{
    int row, col;
    cin >> row >> col;

    for (int i = 1; i <= row; i++)
    {
        for (int j = 1; j <= col; j++)
        {
            if (i == 1 || i == row)              // or 
            {                                    //if( i==1 ||  i == row  ||  j == 1  ||  j == col){
                cout << "*";                     //     cout<<"*";
            }                                    //}
            else if (j == 1 || j == col)         //else{
            {                                    //   cout<<" ";
                cout << "*";                     //  }
            }                                    //}
            else                                 //cout<<endl;
            {                                    //
                cout << " ";
            }
        }
        cout << endl;
    }
}